/**
 * Art asset generator — runs ONCE at development time.
 *
 * Calls z-ai-web-dev-sdk's image generation for each needed asset and saves
 * PNGs into /public/art/. The shipped app only ever references these static
 * files via drawImage — never calls generation at runtime.
 *
 * Usage: bun run scripts/generate-art.ts
 *
 * The game is 100% playable with zero generated assets (the renderer falls
 * back to procedural canvas drawing for any missing file). Treat these as a
 * progressive-enhancement layer.
 */

import ZAI from "z-ai-web-dev-sdk";
import { promises as fs } from "fs";
import path from "path";

const ART_DIR = path.join(process.cwd(), "public", "art");

interface AssetSpec {
  file: string;
  prompt: string;
}

const ASSETS: AssetSpec[] = [
  {
    file: "c172-top.png",
    prompt:
      "Top-down illustration of a white Cessna 172 light aircraft, viewed directly from above, wings level, high-wing configuration, clean minimal aviation training game asset, subtle shading, isolated on a solid dark navy (#0a1530) background, gold accent stripe on wings, no text, centered, crisp edges",
  },
  {
    file: "taildragger-top.png",
    prompt:
      "Top-down illustration of a vintage taildragger light aircraft (Piper Cub style), viewed directly from above, yellow and black, conventional landing gear, clean minimal aviation training game asset, subtle shading, isolated on a solid dark navy (#0a1530) background, no text, centered, crisp edges",
  },
  {
    file: "lowwing-top.png",
    prompt:
      "Top-down illustration of a low-wing light aircraft (Piper Cherokee style), viewed directly from above, white with blue stripes, clean minimal aviation training game asset, subtle shading, isolated on a solid dark navy (#0a1530) background, no text, centered, crisp edges",
  },
  {
    file: "hero-start.png",
    prompt:
      "Wide cinematic illustration of a small airport traffic pattern seen from high above at dusk, a single small airplane flying the rectangular pattern over farmland, runway with edge lights glowing gold, deep navy and indigo sky with warm gold horizon glow, stars, sectional-chart inspired clean illustration style, aviation training product hero image, no text",
  },
];

async function ensureDir() {
  await fs.mkdir(ART_DIR, { recursive: true });
}

async function generateOne(spec: AssetSpec, zai: ZAI): Promise<boolean> {
  const outPath = path.join(ART_DIR, spec.file);
  // Skip if already generated (idempotent).
  try {
    await fs.access(outPath);
    console.log(`  ✓ exists: ${spec.file}`);
    return true;
  } catch {
    /* generate */
  }
  try {
    console.log(`  ⏳ generating: ${spec.file}`);
    const res = await zai.images.generations.create({
      prompt: spec.prompt,
      size: "1024x1024",
    });
    const base64 = res.data[0]?.base64;
    if (!base64) throw new Error("no image data");
    const buf = Buffer.from(base64, "base64");
    await fs.writeFile(outPath, buf);
    console.log(`  ✓ saved: ${spec.file} (${(buf.length / 1024).toFixed(0)} KB)`);
    return true;
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`  ✗ failed: ${spec.file} — ${msg}`);
    return false;
  }
}

async function main() {
  console.log("🎨 Pattern Perfect — art asset generator");
  await ensureDir();
  let zai: ZAI;
  try {
    zai = await ZAI.create();
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`✗ Could not init SDK: ${msg}`);
    console.error("  The game will use procedural fallback art — this is fine.");
    process.exit(0);
  }
  let ok = 0;
  for (const spec of ASSETS) {
    if (await generateOne(spec, zai)) ok++;
  }
  console.log(`\nDone: ${ok}/${ASSETS.length} assets generated. Missing assets fall back to procedural drawing.`);
}

main().catch(() => process.exit(0));
