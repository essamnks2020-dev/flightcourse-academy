"use client";

import { PatternPerfectGame } from "@/components/pattern-perfect/PatternPerfectGame";
import { GameErrorBoundary } from "@/components/pattern-perfect/GameErrorBoundary";
import { Plane, Github, ShieldCheck } from "lucide-react";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <main className="flex-1">
        <GameErrorBoundary>
          <PatternPerfectGame />
        </GameErrorBoundary>
      </main>
      <footer className="mt-auto border-t border-border bg-navy-deep/40 backdrop-blur-md">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-muted-foreground sm:flex-row">
          <div className="flex items-center gap-2">
            <Plane className="h-4 w-4 text-gold" />
            <span className="font-display font-semibold text-foreground">FlightCourse</span>
            <span className="hidden sm:inline">· Pattern Perfect — traffic pattern trainer</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <ShieldCheck className="h-3.5 w-3.5 text-sky" />
              Procedures per FAA AC 90-66C & AIM 4-1-9
            </span>
            <span className="flex items-center gap-1">
              <Github className="h-3.5 w-3.5" />
              Mini-game 3 of 3
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
