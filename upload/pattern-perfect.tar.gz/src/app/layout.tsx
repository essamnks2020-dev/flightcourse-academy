import type { Metadata } from "next";
import { Sora, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const sora = Sora({
  variable: "--font-display",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
});

const inter = Inter({
  variable: "--font-sans",
  subsets: ["latin"],
});

const jetbrains = JetBrains_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FlightCourse — Pattern Perfect",
  description:
    "Pattern Perfect: fly a clean, correctly-called, safely-sequenced traffic pattern. The third mini-game in the FlightCourse trilogy.",
  keywords: [
    "FlightCourse",
    "Pattern Perfect",
    "traffic pattern",
    "flight training",
    "C172",
    "non-towered airport",
    "AC 90-66C",
  ],
  authors: [{ name: "FlightCourse" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${sora.variable} ${inter.variable} ${jetbrains.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
