/**
 * Client-side funnel helper. Fire-and-forget POST to /api/funnel.
 * Mirrors event counts into the local Zustand store for dashboard display.
 */

import { useProgressStore } from "@/lib/store/progress-store";

export type FunnelEventName =
  | "flight-start"
  | "sequencing-conflict-triggered"
  | "radio-call-missed"
  | "flight-complete"
  | "share-tapped";

interface FunnelMeta {
  gameId?: "landing-flare" | "radio-call" | "pattern-perfect";
  sessionId?: string;
  data?: Record<string, unknown>;
}

let sessionId: string | null = null;

function getSessionId(): string {
  if (sessionId) return sessionId;
  if (typeof window !== "undefined") {
    const key = "flightcourse-session";
    let id = window.sessionStorage.getItem(key);
    if (!id) {
      id = `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      window.sessionStorage.setItem(key, id);
    }
    sessionId = id;
    return id;
  }
  return "ssr";
}

export function trackFunnel(name: FunnelEventName, meta: FunnelMeta = {}) {
  const payload = {
    name,
    gameId: meta.gameId ?? "pattern-perfect",
    sessionId: meta.sessionId ?? getSessionId(),
    data: meta.data,
    ts: Date.now(),
  };

  // Mirror locally for the dashboard (non-blocking, safe in SSR).
  try {
    useProgressStore.getState().recordEvent(name);
  } catch {
    /* store not ready in SSR — ignore */
  }

  // Fire-and-forget to the server. Relative path only (gateway-safe).
  if (typeof window !== "undefined") {
    try {
      void fetch("/api/funnel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        keepalive: true,
      });
    } catch {
      /* network failures are non-fatal for a funnel ping */
    }
  }
}
