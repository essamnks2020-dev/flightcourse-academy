---
Task ID: 1
Agent: main (Z.ai Code)
Task: Rebuild the six-pack flight instruments in src/components/views/cockpit-explorer-view.tsx with realistic gauge depth (bezel/screws/glass/gradient), spring-eased CSS-transform needles, carbon-fiber panel, brushed-metal switch rail, a multi-phase demo flight button, category-filter dimming, and full keyboard accessibility.

Work Log:
- Created src/components/views/cockpit-explorer-view.tsx (single self-contained client component, plain-CSS injected via <style dangerouslySetInnerHTML>).
- Wired src/app/page.tsx to render CockpitExplorerView.
- Copied the file to download/cockpit-explorer-view.tsx for direct download.
- Built Gauge shell shared by all 6 instruments: radial-gradient face, conic-gradient metallic bezel (from 135deg, 8 stops), 4 screws at 12/3/6/9 with diagonal slot pseudo-element, convex glass reflection (top-left, rotated -25deg, blur, opacity <=0.18).
- 6 instruments: Airspeed (ticks+labels+white/green/yellow/red arcs+LCD), Attitude (sky/ground horizon that rotates by -bank and translates by pitch, pitch ladder, fixed yellow aircraft symbol, top sky pointer), Altimeter (100s needle, continuous angle, 5-digit LCD), Turn Coordinator (banking miniature aircraft, L/R std-rate marks, 2 MIN label), Heading Indicator (rotating compass card + fixed lubber pointer + heading LCD), VSI (0 at 9 o'clock, +/-2000 scale, signed LCD).
- All needles/moving parts use `transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)` on the CSS `transform` property (verified via getComputedStyle), applied to ASI needle, altimeter needle, VSI needle, DG card, AI horizon, TC aircraft, knobs.
- 4 digital readouts (ASI/ALT/DG/VSI) use backlit-LCD style (#6fd0ff glow, drop-shadow, #05141c bg, inset shadow).
- Carbon-fiber panel via two opposing repeating-linear-gradients + inset shadows; brushed-metal rail via linear-gradient(90deg) with background-size 3px trick + inset highlights.
- Demo flight: setInterval @100ms interpolating 10 keyframes over 14s covering taxi -> takeoff -> climb -> cruise -> descent -> approach/landing; drives ASI+ALT+VSI+DG+AI+TC; button disabled while running; resets to neutral (all zero) at end.
- Category filter (Instrument/Control/Avionics/Switch) toggles .hotspot--dimmed (opacity 0.2) on non-matching hotspots; dimmed hotspots remain clickable/focusable.
- Every hotspot: role=button, tabIndex=0, aria-label, aria-pressed, onClick + onKeyDown(Enter/Space), visible sky-400 focus ring. Tab order = reading order (legend chips, then instruments L->R top then bottom row, then rail items).
- Sticky footer via min-h-screen flex-col + margin-top:auto.

Stage Summary:
- Lint: clean (eslint passes). Dev server: 200 responses, no runtime/console errors.
- Agent-browser + VLM verification: 6 gauges with bezel/screws/glass confirmed; carbon-fiber + brushed rail confirmed; LCD glow confirmed; centered layout, no sidebar confirmed.
- Demo flight sampled via eval at t=0.5/4/8/12/15s: ASI 008/088/120/068/000, ALT 00000/01100/03500/00152/00000, VSI ±0000/+1153/±0000/-0532/±0000, DG 360/005/008/004/360 - all match the keyframe table exactly.
- Hotspot click shows detail card; CONTROL filter dims exactly 10/12 (all non-Controls), the 2 Controls stay bright; toggling off restores all; dimmed Altimeter still selectable.
- Tab order verified correct; focus ring = rgb(56,189,248) 2px solid.
- Mobile (390px): gauges reflow to 2 columns, rail wraps, footer sticks to bottom, nothing cut off.

Artifacts:
- src/components/views/cockpit-explorer-view.tsx (the live component)
- src/app/page.tsx (renders the view at /)
- download/cockpit-explorer-view.tsx (downloadable copy for the user)
