'use client'

import CockpitExplorerView from '@/components/views/cockpit-explorer-view'

export default function Home() {
  return <CockpitExplorerView />
}
