"use client";

import * as React from "react";
import { Radio, LayoutDashboard } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SiteHeader } from "@/components/flightcourse/site-header";
import { SiteFooter } from "@/components/flightcourse/site-footer";
import { CockpitAmbience } from "@/components/flightcourse/cockpit-ambience";
import { RadioBuilder } from "@/components/flightcourse/radio-builder/radio-builder";
import { ProgressDashboard } from "@/components/flightcourse/dashboard/progress-dashboard";

export default function Home() {
  return (
    <div className="fc-app min-h-screen flex flex-col">
      <CockpitAmbience />
      <SiteHeader />
      <main className="flex-1 w-full">
        <div className="mx-auto max-w-5xl px-4 py-6 sm:py-8">
          <Tabs defaultValue="radio">
            <div className="flex justify-center mb-6">
              <TabsList className="fc-glass h-auto p-1 rounded-xl">
                <TabsTrigger
                  value="radio"
                  className="data-[state=active]:bg-gold/20 data-[state=active]:text-gold text-slate-300 px-5 py-2 gap-2 rounded-lg font-medium transition-all"
                >
                  <Radio className="size-4" /> Radio Builder
                </TabsTrigger>
                <TabsTrigger
                  value="dashboard"
                  className="data-[state=active]:bg-gold/20 data-[state=active]:text-gold text-slate-300 px-5 py-2 gap-2 rounded-lg font-medium transition-all"
                >
                  <LayoutDashboard className="size-4" /> Progress
                </TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="radio" className="outline-none">
              <RadioBuilder />
            </TabsContent>
            <TabsContent value="dashboard" className="outline-none">
              <ProgressDashboard />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
