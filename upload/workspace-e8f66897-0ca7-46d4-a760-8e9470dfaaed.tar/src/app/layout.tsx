import type { Metadata } from "next";
import { Sora, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { StoreHydrator } from "@/components/flightcourse/store-hydrator";

const sora = Sora({
  variable: "--font-sora",
  subsets: ["latin"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "FlightCourse — Radio Call Builder",
  description:
    "Learn correct FAA radio phraseology by building real Cessna 172 transmissions, block by block. The free, non-intimidating on-ramp before you ever key a mic.",
  keywords: [
    "FlightCourse",
    "MSFS",
    "X-Plane",
    "Cessna 172",
    "ATC phraseology",
    "radio communications",
    "pilot training",
    "AIM 4-2",
  ],
  authors: [{ name: "FlightCourse" }],
  icons: {
    icon: "/favicon.svg",
    apple: "/favicon.svg",
  },
  openGraph: {
    title: "FlightCourse — Radio Call Builder",
    description:
      "Build correct pilot radio calls block-by-block. FAA-accurate phraseology for the Cessna 172, scored with streaks and shareable results.",
    siteName: "FlightCourse",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FlightCourse — Radio Call Builder",
    description:
      "Build correct pilot radio calls block-by-block. FAA-accurate phraseology for the Cessna 172.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${sora.variable} ${inter.variable} ${jetbrains.variable} antialiased`}
      >
        <StoreHydrator>
          {children}
        </StoreHydrator>
        <Toaster />
      </body>
    </html>
  );
}
