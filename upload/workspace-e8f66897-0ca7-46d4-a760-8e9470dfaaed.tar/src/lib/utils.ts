import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** Fisher–Yates shuffle returning a new array. */
export function shuffle<T>(arr: readonly T[]): T[] {
  const a = arr.slice()
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

export function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n))
}

/** Levenshtein edit distance. */
export function levenshtein(a: string, b: string): number {
  const m = a.length
  const n = b.length
  if (m === 0) return n
  if (n === 0) return m
  const prev = new Array<number>(n + 1)
  const curr = new Array<number>(n + 1)
  for (let j = 0; j <= n; j++) prev[j] = j
  for (let i = 1; i <= m; i++) {
    curr[0] = i
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost)
    }
    for (let j = 0; j <= n; j++) prev[j] = curr[j]
  }
  return prev[n]
}

/** Normalized similarity in [0,1] based on edit distance. */
export function similarity(a: string, b: string): number {
  const sa = a.toLowerCase().replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim()
  const sb = b.toLowerCase().replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim()
  const maxLen = Math.max(sa.length, sb.length)
  if (maxLen === 0) return 1
  const dist = levenshtein(sa, sb)
  return 1 - dist / maxLen
}

/** Token-aware similarity: rewards correct word set + order, forgiving numbers. */
export function phraseSimilarity(spoken: string, target: string): number {
  const norm = (s: string) =>
    s
      .toLowerCase()
      .replace(/[^a-z0-9 ]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
  const sa = norm(spoken).split(" ").filter(Boolean)
  const sb = norm(target).split(" ").filter(Boolean)
  if (sb.length === 0) return 0
  // word-level LCS ratio (order) + set overlap
  const lcs = lcsLen(sa, sb)
  const orderScore = lcs / sb.length
  const setA = new Set(sa)
  const setB = new Set(sb)
  let overlap = 0
  setB.forEach((w) => {
    if (setA.has(w)) overlap += 1
  })
  const setScore = overlap / sb.length
  // edit-distance fallback for close-but-mispronounced numbers
  const charSim = similarity(spoken, target)
  return clamp(0.5 * orderScore + 0.3 * setScore + 0.2 * charSim, 0, 1)
}

function lcsLen(a: string[], b: string[]): number {
  const m = a.length
  const n = b.length
  const dp = new Array<number>(n + 1).fill(0)
  for (let i = 1; i <= m; i++) {
    let prev = 0
    for (let j = 1; j <= n; j++) {
      const tmp = dp[j]
      dp[j] = a[i - 1] === b[j - 1] ? prev + 1 : Math.max(dp[j], dp[j - 1])
      prev = tmp
    }
  }
  return dp[n]
}
