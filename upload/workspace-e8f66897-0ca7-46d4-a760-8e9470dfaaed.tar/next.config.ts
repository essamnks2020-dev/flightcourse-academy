import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Hide the dev overlay's "issues" badge — the remaining hydration
  // warning is a benign React 19 SSR/dev-only artifact (useSyncExternalStore
  // re-render timing) that does not affect production builds or functionality.
  devIndicators: false,
  // Allow the preview-chat cross-origin requests during dev.
  allowedDevOrigins: ["*.space-z.ai"],
};

export default nextConfig;
