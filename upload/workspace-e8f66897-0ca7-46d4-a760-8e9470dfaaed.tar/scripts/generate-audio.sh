#!/bin/bash
# Generate professional, VHF-radio-filtered TTS audio for every fixed phrase.
AUDIO_DIR="/home/z/my-project/public/audio"
TMP_DIR="/tmp/fc-tts"
mkdir -p "$AUDIO_DIR" "$TMP_DIR"

VOICE="jam"
SPEED="0.95"

generate() {
  local id="$1"
  local text="$2"
  local raw="$TMP_DIR/${id}.wav"
  local final="$AUDIO_DIR/${id}.mp3"

  echo -n "  → $id... "
  z-ai tts -i "$text" -o "$raw" --voice "$VOICE" --speed "$SPEED" --format wav > /dev/null 2>&1

  if [ ! -f "$raw" ] || [ ! -s "$raw" ]; then
    echo "TTS FAILED"
    return
  fi

  ffmpeg -y -i "$raw" \
    -af "highpass=f=300,lowpass=f=3400,acompressor=threshold=0.3:ratio=6:attack=2:release=60:makeup=2,volume=2.5,afade=t=in:st=0:d=0.04,afade=t=out:st=0:d=0.1" \
    -ar 24000 -ac 1 -b:a 64k \
    "$final" > /dev/null 2>&1

  if [ -f "$final" ] && [ -s "$final" ]; then
    echo "✓ $(du -h "$final" | cut -f1)"
  else
    echo "FFMPEG FAILED"
  fi
}

echo "=== Generating Radio Audio ==="

generate "example-call" "Watertown Tower, Cessna Seven Three Romeo, at runway two three, ready for takeoff."
generate "nt-downwind" "Watertown traffic, Cessna Seven Three Romeo, downwind runway two three, full stop, Watertown traffic."
generate "nt-entry-45" "Watertown traffic, Cessna Seven Three Romeo, one zero miles southwest, entering four five downwind runway two three, Watertown traffic."
generate "tw-taxi" "Watertown Ground, Cessna Seven Three Romeo, at the main ramp, taxi to runway two three, with information Charlie."
generate "tw-takeoff" "Watertown Tower, Cessna Seven Three Romeo, at runway two three, ready for takeoff."
generate "tw-downwind" "Watertown Tower, Cessna Seven Three Romeo, downwind runway two three, full stop."
generate "tw-approach" "Watertown Tower, Cessna Seven Three Romeo, one zero miles south, at two thousand five hundred, with information Charlie, inbound for full stop."
generate "emergency-mayday" "Mayday, Mayday, Mayday, Watertown Tower, Cessna Seven Three Romeo, engine failure, two miles south of the airport, two thousand feet, attempting runway two three, two souls on board, three hours fuel, Cessna Seven Three Romeo."
generate "radio-check" "Watertown Ground, Cessna Seven Three Romeo, radio check, one two one point niner."
generate "flight-following" "Minneapolis Center, Cessna Seven Three Romeo, Cessna one seven two, two zero miles south of Watertown, at four thousand five hundred, request VFR flight following to Rochester."
generate "runway-crossing" "Watertown Ground, Cessna Seven Three Romeo, at Alpha, approach end runway one one, request crossing runway one one."
generate "rb-taxi-atc" "Cessna Seven Three Romeo, Watertown Ground, runway two three, taxi via Alpha, hold short of runway one one."
generate "rb-altitude-atc" "Cessna Seven Three Romeo, turn right heading zero niner zero, descend and maintain two thousand five hundred."
generate "rb-taxi" "Runway two three, taxi via Alpha, hold short of runway one one, Cessna Seven Three Romeo."
generate "rb-altitude" "Right heading zero niner zero, descend and maintain two thousand five hundred, Cessna Seven Three Romeo."

echo ""
echo "=== Done: $(ls "$AUDIO_DIR"/*.mp3 2>/dev/null | wc -l) files ==="
