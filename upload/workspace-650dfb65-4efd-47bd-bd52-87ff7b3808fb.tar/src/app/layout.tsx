import type { Metadata } from "next";
import { Sora, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";

const sora = Sora({
  variable: "--font-sora",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "FlightCourse — Landing Flare Trainer",
  description:
    "Master the Cessna 172 flare. A 60fps physics-driven mini-game from FlightCourse — read the PAPI, time your flare, stick the greaser, and share your landing.",
  keywords: [
    "FlightCourse",
    "Cessna 172",
    "flight simulator",
    "MSFS",
    "X-Plane",
    "landing flare",
    "pilot training",
    "mini-game",
  ],
  authors: [{ name: "FlightCourse" }],
  openGraph: {
    title: "FlightCourse — Landing Flare Trainer",
    description:
      "Master the Cessna 172 flare. Time your flare, stick the greaser, share your landing.",
    siteName: "FlightCourse",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FlightCourse — Landing Flare Trainer",
    description:
      "Master the Cessna 172 flare. Time your flare, stick the greaser, share your landing.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${sora.variable} ${inter.variable} ${jetbrains.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <Toaster richColors position="top-center" />
        </ThemeProvider>
      </body>
    </html>
  );
}
