import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

/**
 * Leaderboard API — sync-ready endpoint.
 * GET  /api/leaderboard            → top scores globally
 * GET  /api/leaderboard?playerId=  → that player's best
 * POST /api/leaderboard            → submit an attempt + upsert best
 *
 * Today this is best-effort: the client works fully offline (localStorage),
 * and submits here so a real leaderboard exists the moment we wire auth.
 */
export async function GET(req: NextRequest) {
  const playerId = req.nextUrl.searchParams.get('playerId')
  try {
    if (playerId) {
      const entry = await db.leaderboardEntry.findUnique({ where: { playerId } })
      return NextResponse.json({ entry })
    }
    const top = await db.leaderboardEntry.findMany({
      orderBy: { bestScore: 'desc' },
      take: 25,
    })
    return NextResponse.json({ leaderboard: top })
  } catch {
    // DB may not be pushed yet — degrade gracefully.
    return NextResponse.json({ leaderboard: [], error: 'db_unavailable' })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { playerId, playerName, score, quality, totalLandings } = body ?? {}

    if (!playerId || typeof score !== 'number') {
      return NextResponse.json({ ok: false, error: 'bad_payload' }, { status: 400 })
    }

    await db.gameAttempt.create({
      data: {
        playerId,
        score: Math.round(score),
        quality: String(quality ?? 'unknown'),
        touchdownVSI: Number(body.touchdownVSI ?? 0),
        touchdownAirspeed: Number(body.touchdownAirspeed ?? 0),
        touchdownDistance: Number(body.touchdownDistance ?? 0),
        flareAltitude: Number(body.flareAltitude ?? 0),
        bounces: Number(body.bounces ?? 0),
        stalled: Boolean(body.stalled),
        crosswind: Boolean(body.crosswind),
        durationMs: Number(body.durationMs ?? 0),
      },
    })

    const existing = await db.leaderboardEntry.findUnique({ where: { playerId } })
    const newBest = Math.max(existing?.bestScore ?? 0, Math.round(score))
    await db.leaderboardEntry.upsert({
      where: { playerId },
      create: {
        playerId,
        playerName: playerName ?? null,
        bestScore: newBest,
        bestQuality: String(quality ?? 'unknown'),
        totalLandings: Math.max(existing?.totalLandings ?? 0, Number(totalLandings ?? 1)),
      },
      update: {
        playerName: playerName ?? existing?.playerName ?? null,
        bestScore: newBest,
        bestQuality:
          newBest > (existing?.bestScore ?? 0)
            ? String(quality ?? 'unknown')
            : existing?.bestQuality ?? String(quality ?? 'unknown'),
        totalLandings: Math.max(
          existing?.totalLandings ?? 0,
          Number(totalLandings ?? existing?.totalLandings ?? 1),
        ),
      },
    })

    return NextResponse.json({ ok: true, bestScore: newBest })
  } catch {
    return NextResponse.json({ ok: false, error: 'db_unavailable' })
  }
}
