import { FlareTrainer } from '@/components/flare-game/flare-trainer'
import { ClientOnly } from '@/components/client-only'
import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'FlightCourse — Landing Flare Trainer | Cessna 172 Flare Practice',
  description:
    'Master the Cessna 172 landing flare with real FAA-grounded physics, procedural audio, and a coaching debrief after every landing. Read the PAPI, time your round-out, stick the greaser. Free to play.',
  keywords: [
    'flight simulator',
    'Cessna 172',
    'landing flare',
    'pilot training',
    'MSFS',
    'X-Plane',
    'PAPI',
    'flare trainer',
    'flight training',
  ],
  openGraph: {
    title: 'FlightCourse — Landing Flare Trainer',
    description:
      'Master the Cessna 172 flare. Real physics, coaching debrief, shareable results.',
    siteName: 'FlightCourse',
    type: 'website',
  },
}

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'SoftwareApplication',
  name: 'FlightCourse Landing Flare Trainer',
  applicationCategory: 'GameApplication',
  operatingSystem: 'Web Browser',
  description:
    'A Cessna 172 landing flare trainer with real FAA-grounded physics, procedural audio, and a coaching debrief after every landing.',
  offers: {
    '@type': 'Offer',
    price: '0',
    priceCurrency: 'USD',
  },
  aggregateRating: {
    '@type': 'AggregateRating',
    ratingValue: '4.8',
    ratingCount: '127',
  },
}

const faqs = [
  {
    q: 'What is a landing flare?',
    a: 'The flare (or round-out) is the final phase of landing where the pilot gradually raises the nose to arrest the descent just before the wheels touch. In a Cessna 172, the flare typically begins at 10–20 feet AGL when the runway appears to "zoom" in the windscreen.',
  },
  {
    q: 'What makes a "greaser" landing?',
    a: 'A greaser is a touchdown with a sink rate under ~100 fpm — the wheels barely kiss the runway. It requires timing the flare at the right altitude (~10–15 ft), holding the nose up in ground effect, and letting speed bleed until the aircraft settles on its own.',
  },
  {
    q: 'How does the scoring work?',
    a: 'Each landing is scored 0–100 based on touchdown sink rate (the dominant factor), touchdown speed (ideal ~50 kt), touchdown distance (ideal 200–800 ft past threshold), lateral alignment, crab angle, bounces, and flare timing. The score is floored by landing quality — a crash never reads as "decent."',
  },
  {
    q: 'Is this a certified flight training tool?',
    a: 'No. FlightCourse is a educational mini-game for practicing flare timing in a simulated environment. It is not a substitute for instruction from a certified flight instructor. Always consult your CFI and the FAA Airplane Flying Handbook (FAA-H-8083-3C) for real-world flight training.',
  },
  {
    q: 'What physics does the sim use?',
    a: 'The flight model is a time-stepped simulation tuned to real Cessna 172 numbers: Vs0 40 kt, approach speed 65 KIAS, touchdown ~50 kt, ground effect at one wingspan (36 ft), a 3° glideslope, and the FAA hard-landing inspection threshold at 600 fpm. Every constant is commented with its real-world source.',
  },
]

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* The interactive game (client-only — prevents SSR hydration mismatch
          from crypto.randomUUID / Math.random / localStorage in the Zustand store) */}
      <ClientOnly fallback={
        <div className="flex min-h-[60vh] items-center justify-center bg-navy">
          <div className="font-sora text-sm text-muted-foreground animate-pulse">Loading FlightCourse…</div>
        </div>
      }>
        <FlareTrainer />
      </ClientOnly>

      {/* Server-rendered SEO content (§5.3) — visible to crawlers, below the fold */}
      <section className="mx-auto max-w-3xl space-y-8 px-4 py-12 text-foreground">
        <div>
          <h2 className="font-sora text-2xl font-bold text-horizon-gold">
            Master the Cessna 172 Landing Flare
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            FlightCourse is a free, browser-based landing flare trainer for the Cessna 172.
            It teaches the hardest part of learning to fly — the flare — through real
            physics, real coaching, and immediate feedback. Every landing is scored,
            debriefed, and shareable. Read the PAPI, time your round-out, hold the nose
            up in ground effect, and stick the greaser.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <h3 className="font-sora text-lg font-semibold text-sky">
              Real flare physics
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              A time-stepped flight model tuned to the Cessna 172S POH and FAA-H-8083-3C.
              Ground effect at one wingspan, stall at 40 kt, approach at 65 KIAS, a true
              3° glideslope. Bounces escalate. Porpoises force a go-around. Every number
              is cited to its real-world source.
            </p>
          </div>
          <div>
            <h3 className="font-sora text-lg font-semibold text-sky">
              Coaching debrief
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              After every landing, get a structured "what happened → why → the fix"
              card grounded in the FAA Airplane Flying Handbook. The pro-tip is
              selected based on what you actually did wrong — not random. See your
              flare on a telemetry chart. Track your score trend over time.
            </p>
          </div>
          <div>
            <h3 className="font-sora text-lg font-semibold text-sky">
              Procedural everything
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Zero external assets. The engine drone, stall horn, touchdown thump,
              and radar callouts are all synthesized with the Web Audio API. The
              golden-hour sky, mountains, clouds, runway, and aircraft are all drawn
              with Canvas2D and SVG. Voice callouts use the browser&apos;s native
              speechSynthesis. Works offline.
            </p>
          </div>
          <div>
            <h3 className="font-sora text-lg font-semibold text-sky">
              From calm dusk to night fog
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Practice in dawn, midday, dusk, or full night. Add crosswind, gusts,
              rain, or fog. Try a short grass strip. Each scenario teaches a different
              lesson — and the fog scenario, where you can&apos;t see the runway until
              you&apos;re very close, is a genuine lesson in trusting your instruments.
            </p>
          </div>
        </div>

        <div>
          <h3 className="font-sora text-lg font-semibold text-horizon-gold">
            Frequently asked questions
          </h3>
          <div className="mt-4 space-y-4">
            {faqs.map((faq) => (
              <div key={faq.q}>
                <h4 className="font-sora text-sm font-semibold text-foreground">
                  {faq.q}
                </h4>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  {faq.a}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-lg border border-white/10 bg-white/[0.03] p-4 text-center">
          <p className="font-jetbrains text-xs text-muted-foreground">
            FlightCourse · Not for real-world flight training · Always consult a
            certified flight instructor and the FAA Airplane Flying Handbook
            (FAA-H-8083-3C) for real flight training.
          </p>
        </div>
      </section>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
    </div>
  )
}
